package com.salaryviewer.SalaryViewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalaryViewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
