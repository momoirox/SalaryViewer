package com.salaryviewer.SalaryViewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalaryViewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalaryViewerApplication.class, args);
	}

}
